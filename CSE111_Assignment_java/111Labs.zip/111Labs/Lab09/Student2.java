package Lab09;

public class Student2 {
    public static int total;
    public static int cse;
    public static int bba;
    public int deptSerial;

    public String name;
    public String dept;

    public Student2(String name, String dept){
        this.name = name;
        this.dept = dept;
        if(dept.equals("CSE")){
            cse++;
            deptSerial++;
        }
        else if(dept.equals("BBA")){
            bba++;
            deptSerial++;
        }
        total++;
    }
    public void individualInfo(){
        System.out.println(name+" is from "+dept+" department.");
        System.out.println("Serial of "+name+" among all students' is: "+total);
        if(dept.equals("CSE")){
            System.out.println("Serial of "+name+" in "+dept+" is: "+cse);
        }
        else{
            System.out.println("Serial of "+name+" in "+dept+" is: "+bba);
        }
    }

    public static void totalInfo(){
        System.out.println("Total Students: "+total);
        System.out.println("Total CSE students: "+cse);
        System.out.println("Total BBA students: "+bba);
    }
}
