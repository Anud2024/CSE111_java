package Lab09;

public class Bus {
    public int capacity;
    public String destination;
    public int count;

    public Bus(int capacity, String destination){
        this.capacity = capacity;
        this.destination = destination;
        System.out.println("Capacity: "+capacity);
        System.out.println("Destination: "+destination);
    }
    public void addPassenger(String name, String stop){
        if(!stop.equals("Jatrabari")){
            System.out.println("Sorry "+name+"! The bus won't stop at "+ stop+"\nUse another bus.");
        }
        else{
            addPassenger(name);
        }
    }
    public void addPassenger(String name){
        if(count<capacity){
            System.out.println(name+" is added to the bus\n"+name+" will get off at the last stop");
            count++;
        }
        else{
            System.out.println("Bus is full");
        }
    }
}
