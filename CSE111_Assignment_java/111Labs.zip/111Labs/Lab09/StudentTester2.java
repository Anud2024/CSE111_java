package Lab09;
public class StudentTester2{
    public static void main(String[] args) {
      Student2 s1 = new Student2("Naruto", "CSE");
      System.out.println("1----------------");
      s1.individualInfo();
      System.out.println("################");
      Student2.totalInfo();
      System.out.println("==================");
      Student2 s2 = new Student2("Sakura", "BBA");
      System.out.println("2----------------");
      s2.individualInfo();
      System.out.println("################");
      Student2.totalInfo();
      System.out.println("==================");
      Student2 s3 = new Student2("Shikamaru", "CSE");
      System.out.println("3----------------");
      s3.individualInfo();
      System.out.println("################");
      Student2.totalInfo();
      System.out.println("==================");
      Student2 s4 = new Student2("Deidara", "BBA");
      System.out.println("4----------------");
      s4.individualInfo();
      System.out.println("################");
      Student2.totalInfo();
    }
  }
  