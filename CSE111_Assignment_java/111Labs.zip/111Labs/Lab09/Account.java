package Lab09;

public class Account{
    public double balance = 0.0;
    
    public Account(double balance){
      this.balance = balance;
    }
    public double showBalance(){
      return balance;
    }
  }
  
