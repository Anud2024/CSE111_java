public class Smartphone{
    public String name;
    public String display;
    public String ram;

    public Smartphone(){}
    public Smartphone(String name){
        this.name = name;
    }

    public void addFeature(String comp, String feature) {
        if (name == null) {
            System.out.println("Feature can not be added without phone name");
        } else {
            if (comp.equals("Display")) {
                if (display == null) {
                    display = feature;
                } else {
                    display += ", " + feature;
                }
            } else if (comp.equals("Ram")) {
                if (ram == null) {
                    ram = feature;
                } else {
                    ram += ", " + feature;
                }
            }
        }
    }
        public void printDetail(){
            System.out.println("Phone Name: " + name);
            if (display != null) {
                System.out.println("Display: " + display);
            }
            if (ram != null) {
                System.out.println("Ram: " + ram);
            }
        }
        public void updateName(String name){
            this.name = name;
        }
    }