package Lab09;
class BBAStudent extends Student {
    BBAStudent(){
        super();
        updateName("Default");
        updateDepartment("BBA");
    }
    BBAStudent(String name){
        super();
        updateName(name);
        updateDepartment("BBA");
    }
}