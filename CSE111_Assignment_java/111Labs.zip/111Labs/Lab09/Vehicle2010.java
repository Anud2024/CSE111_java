package Lab09;

public class Vehicle2010 extends Vehicle {
    public void moveLowerLeft(){
        super.moveLeft();
        super.moveDown();
    }
    public void moveUpperRight(){
        super.moveUp();
        super.moveRight();
    }
    public void moveLowerRight(){
        super.moveDown();
        super.moveRight();
    }
}
