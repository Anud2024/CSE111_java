package Lab09;

public class AccountTester{
    public static void main(String[] args) {
      System.out.println("Total account holders: " + Account2.count);
      System.out.println("1================");
      Account2 p1 = new Account2("Abdul",45,"Service Holder",500000);
      p1.addMoney(300000);
      p1.printDetails();
      System.out.println("2================");
      Account2 p2 = new Account2("Rahim",55,"Businessman",700000);
      p2.withdrawMoney(700000);
      p2.printDetails();
      System.out.println("3================");
      Account2 p3 = new Account2("Ashraf",62,"Govt.Officer",200000);
      p3.withdrawMoney(250000);
      p3.printDetails();
      System.out.println("4================");
      System.out.println("Total account holders: " + Account2.count);
    }
  }
  
