package Lab09;

public class Account2 {
    public static int count;
    public String name;
    public int age;
    public String occupation;
    public int amount;

    public Account2(String name, int age, String occupation, int amount){
        this.name = name;
        this.age = age;
        this.occupation = occupation;
        this.amount = amount;
        count++;
    }
    public void addMoney(int amount){
        this.amount += amount;
    }
    public void printDetails(){
        System.out.println("Name: "+name);
        System.out.println("Age: "+age);
        System.out.println("Occupation: "+occupation);
        System.out.println("Total Amount: "+amount);
    }
    public void withdrawMoney(int amount){
        if(amount<= this.amount){
            this.amount -= amount;
        }
    }
}
