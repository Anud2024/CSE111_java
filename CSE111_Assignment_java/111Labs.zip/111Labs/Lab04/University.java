public class University{
    public String name;
    public String country;
}