public class Tournament {
    public String name;
    public String sportsType;
    public int numberOfTeams;
    public String[] teams;
}
