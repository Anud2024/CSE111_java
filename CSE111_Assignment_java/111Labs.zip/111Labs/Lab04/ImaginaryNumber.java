public class ImaginaryNumber {
    int realPart;
    int imaginaryPart;
    public void printNumber(){
        System.out.println(realPart + "+" + imaginaryPart+"i");
    }
}
