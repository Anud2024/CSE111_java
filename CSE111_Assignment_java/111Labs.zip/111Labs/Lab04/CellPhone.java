public class CellPhone {
    public String model = "unknow";
    String[] contact = new String[3];
    int contactCount = 0;
    public void printDetails(){
        System.out.println("Phone Model "+model);
        System.out.println("Contacts Stored "+contactCount);
        for(int i = 0; i < contactCount; i++){
            System.out.println(contact[i]);
        }
    }

    public void storeContact(String info){
        if(contactCount<3){
            contact[contactCount] = info;
            contactCount++;
            System.out.println("Contact Stored");
        }
        else{
            System.out.println("Memory full. New contact can't be stored.");
        }
    }

}
