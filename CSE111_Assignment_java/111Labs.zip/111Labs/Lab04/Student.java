public class Student{
    public String name = "Bob";
    public int id = 1;
}