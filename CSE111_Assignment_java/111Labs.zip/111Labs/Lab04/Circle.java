public class Circle{
    public double radius = 5;
}