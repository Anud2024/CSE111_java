public class Cat {
    public String color = "White";
    public String action = "sitting";
    public void printCat(){
        System.out.println(color+" cat is "+action);
    }
}
