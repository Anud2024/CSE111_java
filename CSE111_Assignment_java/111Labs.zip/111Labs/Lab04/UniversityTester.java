public class UniversityTester{
    public static void main(String[] args){
        //a
        University u1 = new University();
        University u2 = new University();
        System.out.println(u1);
        System.out.println(u2);
        System.out.println(u1.name + "\n" + u1.country);
        System.out.println(u2.name + "\n" + u2.country);

        System.out.print("The location of object: ");
        if(u1==u2){
            System.out.println("Same");
        }
        else{
            System.out.println("Not same");
        }
        //b
        u1.name = "Imperial College London";
        u1.country = "England";

        u2.name = "Brac University";
        u2.country = "Bangladesh";

        System.out.println(u1.name + "\n" + u1.country);
        System.out.println(u2.name + "\n" + u2.country);

        System.out.print("Did the instance variable change? ");
        if(u1.name!=null && u1.country!=null && u2.name !=null && u2.country!=null){
            System.out.println("All Changed");
        }
        else{
            System.out.println("Did not change");
        }

        System.out.print("For name variable, the value: ");
        if(u1.name.equals(u2.name)){
            System.out.println("Same");
        }
        else{
            System.out.println("Not same");
        }
        System.out.print("For country variable, the valeu: ");
        if(u1.country.equals(u2.country)){
            System.out.println("Same");
        }
        else{
            System.out.println("Not same");
        }
        
    }
}