public class Test2{
    public static void main(String[] args){
        Circle c1 = new Circle();
        System.out.println("Radius of the circle is "+c1.radius);
        double area = 3.141592653589793 * c1.radius * c1.radius;
        System.out.println("The area of the circle is "+area);
        double circumference = 2 * 3.141592653589793 * c1.radius;
        System.out.println("The circumference of the circle is "+circumference);
    }
}