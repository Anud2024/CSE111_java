public class Bird {
    public String name;
    int height;
    public void flyUp(int h){
        height += h;
        System.out.println(name+" has flown up "+h+" feet.");
    }
    public void flyDown(int h){
        if(h<height){
            height-=h;
            System.out.println(name+" has flown down "+h+" feet.");
        }
        else if(h==height){
            height-=h;
            System.out.println(name+" has flow down "+h+" feet and landed");
        }
        else{
            System.out.println(name+" cannot fly down " + h+ " feet.");
        }
    }
    public void makeNoise(){
        if(name.equals("Parrot")){
            System.out.println("Squawk");
        }
        if(name.equals("Eagle")){
            System.out.println("Squee");
        }
    }
}
