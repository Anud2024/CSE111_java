public class Vehicle{
    public String type = "Car";
    public int wheels = 4;
    public String color = "White";
}