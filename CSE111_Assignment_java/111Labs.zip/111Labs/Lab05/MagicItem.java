public class MagicItem {
    public String name;
    public int level;
    public String item1, item2, item3;
    public int Potion = 50, Elixir = 100, Amulet = 200;

    public void newCharacter(String name){
        this.name = name;
    }
    public void findItem(String item){
        boolean found = false;
        if(item1==null){
            item1 = item;
            found = true;
        }
        else if(item2 == null){
            item2 = item;
            found = true;
        }
        else if(item3== null){
            item3 = item;
            found = true;
        }
        else{
            System.out.println("All item slots occupied.");
        }
        if(found){
            System.out.println(name+" found a "+item);
        }
    }
    public void useItem(String item){
        boolean found = true;
        if(item.equals(item1)){
            item1 = null;
        }
        else if(item.equals(item2)){
            item2 = null;
        }
        else if(item.equals(item3)){
            item3 = null;
        }
        else{
            System.out.println("Item not in invertory");
            found = false;
        }
        if(found){
            System.out.println(name+" used a "+item);
            if(item.equals("Potion")){
                level+=Potion;
            }
            if(item.equals("Elixir")){
                level+=Elixir;
            }
            if(item.equals("Amulet")){
                level+=Amulet;
            }
            System.out.println("Energy level after using item: "+level);
        }
    }

    public void displayInfo(){
        System.out.println("Character Name: "+name);
        System.out.println("Energy Level: "+level);
        System.out.println("Item 1: "+item1);
        System.out.println("Item 1: "+item2);
        System.out.println("Item 1: "+item3);
        
    }


}
