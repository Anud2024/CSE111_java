public class Dog {
    public String name;
    public String color;
    
    public void changeName(String name){
        this.name = name;
    }
    public void changeColor(String color){
        this.color = color;
        if(name != null){
            System.out.println(this.name+" is "+this.color);
        }
        else{
            System.out.println("This dog is "+this.color);
        }
    }
    public String bark(){
        String rString = "";
        if(name ==null && color == null){
            rString = "A dog is barking";
        }
        else if(name == null){
            rString = "The "+color+" dog is barking";
        }
        else if(color == null){
            rString = name+" is barking";
        }
        else{
            rString = name+" the " + color + " dog is barking";
        }
        return rString;
    }
}
