public class Employee {
    public String name;
    public double salary = 30000;
    public String designation = "junior";

    public void newEmployee(String name){
        this.name = name;
    }
    public void promoteEmployee(String designation){
        this.designation = designation;
        if(designation.equals("senior")){
            salary += 25000;
        }
        else if(designation.equals("lead")){
            salary += 50000;
        }
        else if(designation.equals("manager")){
            salary += 75000;
        }
        System.out.println(name+" has been promoted to "+this.designation);
        System.out.println("New Salary: "+this.salary);
    }
    public void calculateTax(){
        double tax;
        if(salary>50000){
            tax = salary * 0.30;
            System.out.println(name+" Tax Amount: "+tax);
        }
        else if(salary>30000){
            tax = salary * 0.1;
            System.out.println(name+" Tax Amount: "+tax);
        }
        else{
            System.out.println("No need to pay tax");
        }
    }
    public void displayInfo(){
        System.out.println("Employee Name: "+name);
        System.out.println("Employee Salary: "+salary);
        System.out.println("Employee Designation: "+designation);
    }

}
