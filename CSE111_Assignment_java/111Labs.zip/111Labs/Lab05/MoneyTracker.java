public class MoneyTracker {
    public String name;
    public double balance;
    public double added;
    public double spent;

    public void createTracker(String name){
        this.name = name;
        balance = 1;
    }
    public void income(double income){
        balance += income;
        System.out.println("Balanace Updated");
        added = income;
    }
    public void expense(double expense){
        if(expense<=balance){
            balance -= expense;
            System.out.println("Balance Updated");
            spent = expense;
            
        }
        else if(balance == 0){
            System.out.println("You're broke!");
        }
        else{
            System.out.println("Not enough balance.");
        }
    }
    public String info(){
        return "Name :"+name+"\nCurrent Balance: "+balance;
    }

    public void showHistory(){
        System.out.println("Last added: "+added);
        System.out.println("Last spent: "+spent);
    }
}