public class Book {
    public String name;
    public String author;
    public int price;

    public Book(String name){
        this.name = name;
    }

    public Book(String name, String author){
        this(name);
        this.author = author;
    }

    public Book(String name, String author, int price){
        this(name, author);
        setDetails(price);
    }

    public void setDetails(String author){
        this.author = author;
    }
    public void setDetails(int price){
        this.price = price;
    }
    public void setDetails(String author, int price){
        setDetails(author);
        setDetails(price);
    }

    public void displayDetails(){
        if(author == null){
            if(price == 0){
                System.out.println("Title: "+name);
            }
            else{
                System.out.println("Title: "+name+", Price: "+price);
            }

        }
        else if(price == 0){
            System.out.println("Title: "+name+", Author: "+author);
        }

        else {
            System.out.println("Title: " + name + ", Author: " + author + " Price: " + price);
        }
    }
}
