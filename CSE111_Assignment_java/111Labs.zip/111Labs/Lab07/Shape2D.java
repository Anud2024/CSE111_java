public class Shape2D {
    public String type;
    public double area;

    public Shape2D(int length){
        this.type = "Square";
        this.area = length* length;
        System.out.println(shapeType()+"length: "+length);
    }
    public Shape2D(int length, int breadth){
        this.type = "Rectangle";
        this.area = length*breadth;
        System.out.println(shapeType()+ "length: "+length+" and breadth: "+breadth);
    }
    public Shape2D(int height, int base, String type){
        this.area = 0.5 * height * base;
        System.out.println(shapeType()+height+" and "+base);
    }
    public Shape2D(int a, int b, int c){
        this.type = "Triangle";
        double s = (a + b + c)/2.0;
        area = Math.sqrt(s*(s-a)*(s-b)*(s-c));
        System.out.println(shapeType()+"the following sides: "+a+", "+b+", "+c);
    }
    public void area(){
        System.out.println("The area of the following "+this.type+ " is: "+area);
    }
    public String shapeType(){
        return "A "+this.type+" has been created with ";
    }
}
