class Student {
    private int id;
    private double cg;
    private String[] courses = new String[4];
    private int courseCount;

    public Student(int id) {
        this.id = id;
    }

    public Student(int id, double cg) {
        this.id = id;
        this.cg = cg;
    }

    public void setID(int id) {
        this.id = id;
    }

    public void setCG(double cg) {
        this.cg = cg;
    }

    public void addCourse(String course) {
        if (cg < 3 && courseCount == 3) {
            System.out.println("CG is low. Can't add more than 3 courses.");
        }
        if (courseCount == 4) {
            System.out.println("Maximum 4 courses allowed.");
        }
        if (cg == 0) {
            System.out.println("Set CG first");
        }
        courses[courseCount++] = course;
    }

    public void addCourse(String[] courses) {
        for(int i = 0; i < courses.length; i++){
            String course = courses[i];
            addCourse(course);
            if(courseCount==3 && cg < 3){
                break;
            }
            else if(courseCount == 4){
                break;
            }
        }
    }

    public void rmAllCourse() {
        this.courseCount = 0;
        for (int i = 0; i < courses.length; i++) {
            courses[i] = null;
        }
    }

    public void showAdvisee() {
        System.out.println("Student ID: " + id + ", CGPA: " + cg);
        if (courseCount == 0) {
            System.out.println("No courses added.");
            return;
        }
        System.out.print("Added courses are: ");
        for (int i = 0; i < courseCount; i++) {
            System.out.print(courses[i] + " ");
        }
        System.out.println();
    }
}