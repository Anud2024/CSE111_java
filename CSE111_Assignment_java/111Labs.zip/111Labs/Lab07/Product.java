public class Product {
    private String name;
    private double price;
    private int quantity;

    public Product(){}
    public Product(String name, double price){
        this.name = name;
        this.price = price;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    public double getPrice(){
        return this.price;
    }
    public int getQuantity(){
        return this.quantity;
    }
    public void displayInfo(){
        if(name == null){
            System.out.println("Product Name: Unknown");
            System.out.print("Price: $"+price);
        }
        else{
            System.out.println("Product Name: "+name);
            System.out.println("Price: "+price);
            System.out.println("Quantity: "+quantity);
        }
    }
}
