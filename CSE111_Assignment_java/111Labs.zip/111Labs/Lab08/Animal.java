package Lab08;
public class Animal{ 
    public int legs = 4;
    public String sound = "Not defined";
    
    public void details(){
      System.out.println("Legs: "+legs);
      System.out.println("Sound: "+sound);
    }
  }
  