package Lab08;

public class Passenger {
    public static int no_of_passenger;
    public static double total_fare;

    public String name;
    public double distance;
    public double weight;

    public Passenger(String name, double distance){
        this.name = name;
        this.distance = distance;
        no_of_passenger++;
    }
    public void setBaggageWeight(double weight){
        this.weight = weight;
    }
    public void passengerDetails(){
        double fare = distance * 20 + weight * 10;
        total_fare += fare;
        System.out.println("Name: "+name);
        System.out.println("Fare: "+fare);
    }
}
