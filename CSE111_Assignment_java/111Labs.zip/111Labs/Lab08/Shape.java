package Lab08;
public class Shape {
    public String name;
    public String color;
  
    public void displayInfo() {
      System.out.printf("Name: %s\nColor: %s\n", name, color);
    }
  }