package Lab08;

public class Borrower{
    public static int book_count[] = {3, 3, 3};
    public static String book_name[] = {"Pather Panchali", "Durgesh Nandini", "Anandmath"};
  
    public String name;
    public String bookBorrowed = "";

    public Borrower(String name){
      this.name = name;
    }
    public void borrowBook(String book){
      for(int i = 0; i < book_name.length; i++){
        if(book_name[i].equals(book)){
          if(book_count[i]>0){
            book_count[i]--;
            bookBorrowed += (book+"\n");
            break;
          }
          else{
            System.out.println("This book is not available.");
            break;
          }
        }
      }
    }
    public static void bookStatus(){
      System.out.println("Available Books:");
      for(int i = 0; i < book_count.length; i++){
        System.out.println(book_name[i]+": "+book_count[i]);
      }
    }
    public void borrowerDetails(){
      System.out.println("Name: "+name);
      System.out.println("Books Borrowed:");
      System.out.print(bookBorrowed);
    }
    public static int remainingBooks(String book){
      for(int i = 0; i < book_name.length; i++){
        if(book_name[i].equals(book)){
          return book_count[i];
        }
      }
      return 0;
    }
  }
