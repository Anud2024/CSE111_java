package Lab08;

public class Student {
    public static int totalStudentCount;
    public static int cseCount;
    public static int othersCount;
    public static int ID;

    public String name;
    public double cg;
    public String dept = "CSE";

    public Student(String name, double cg){
        this.name = name;
        this.cg = cg;
        totalStudentCount++;
        cseCount++;

    }
    public Student(String name, double cg, String dept){
        this.name = name;
        this.cg = cg; 
        this.dept = dept;
        boolean t = dept.equals("CSE");
        if(!t){
            othersCount++;
        }
        else{
            cseCount++;
        }
        totalStudentCount++;
    }
    public static Student createStudent(String name, double cg, String dept){
        Student s = new Student(name, cg, dept);
        return s;
    }
    public void individualDetail(){
        System.out.println("ID: "+ID);
        System.out.println("Name: "+name);
        System.out.println("CGPA: "+cg);
        System.out.println("Department: "+dept);
    }
    public static void printDetails(){
        System.out.println("Total Student(s): "+totalStudentCount);
        System.out.println("CSE Student(s): "+cseCount);
        System.out.println("Other Department Student(s): "+othersCount);
    }

}
