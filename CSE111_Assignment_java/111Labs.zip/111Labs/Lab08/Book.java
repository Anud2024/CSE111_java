package Lab08;

public class Book {
    public static int total_books_sold;
    public static double total_revenue;
    public String name;
    public int discount;
    public double price = 150;

    public Book(String name, int discount){
        this.name = name;
        this.discount = discount; 
        total_books_sold++;
        total_revenue += discountPrice();   
    }
    public void bookDetails(){
        System.out.println("Title: "+name);
        System.out.println("Price after Discount: "+discountPrice());
        
    }

    public double discountPrice(){
        return price - (price* (discount/100.0));
    }

}
