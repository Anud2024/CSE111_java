package Lab08;
public class Dog extends Animal{
    public Dog(){
        System.out.println("The Dog says hello!");
    }
    public void updateSound(String sound){
        this.sound = sound;
    }
    public String name;
    public String getName(){
        return name;
    }
}
