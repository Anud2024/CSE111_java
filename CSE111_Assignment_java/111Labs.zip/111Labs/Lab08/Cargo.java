package Lab08;

public class Cargo {
    public static int ID;
    public static double capacity = 10;
    public static double tWeight;
    public int id;
    public String contents;
    public boolean loaded;
    public double weight;

    public Cargo(String contents, double weight){
        this.contents = contents;
        this.weight = weight;
        this.id = ID++;
    }
    public void details(){
        System.out.println("Cargo ID: "+this.id+", Contents: "+contents + ", Weight: "+weight+", Loaded: "+loaded);
    }
    public void load(){
        loaded = true;
        if((capacity - tWeight) >= weight){
            System.out.println("Cargo "+this.id+ " loaded for transport");
            tWeight+=this.weight;
        }
        else{
            System.out.println("Cannot load cargo, exceed weight capacity");
        }  
    }
    public void unload(){
        loaded = false;
        System.out.println("Cargo "+this.id+" unloaded");
        tWeight-=this.weight;
    }

    public static double capacity(){
        return capacity-tWeight;
        
    }
}
