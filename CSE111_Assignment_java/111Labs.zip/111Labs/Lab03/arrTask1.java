import java.util.Scanner;
public class arrTask1 {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        System.out.print("N = ");
        int N = input.nextInt();
        int[] arr = new int[N];
        for(int i = 0; i < arr.length; i++){
            arr[i] = input.nextInt();
        }
        System.out.print("Remove Element = ");
        int remove = input.nextInt();

        boolean removal = false;
        for(int i = 0; i < arr.length; i++){
            if(arr[i] == remove){
                removal = true;
            }
        }
        System.out.println("Input array:");
        for(int i = 0; i < arr.length; i++){
            System.out.print(arr[i]+" ");
        }
        System.out.println();
        if(removal){
            int[] newArr = new int[N-1];
            for(int i = 0, j = 0; i < arr.length && j < N-1; i++, j++){
                if(arr[i]!= remove){
                    newArr[j] = arr[i];
                }
            }
            System.out.println("New array: ");
            for(int i = 0; i < newArr.length; i++){
                System.out.print(newArr[i]+ " ");
            }
        }   
    }
}
