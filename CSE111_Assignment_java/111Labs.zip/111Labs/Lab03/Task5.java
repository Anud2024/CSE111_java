import java.util.Scanner;
public class Task5 {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        String s1 = input.nextLine();
        String s2 = input.nextLine();
        String s3 = s1 + " " + s2;
        int sum = 0;
        for(int i = 0; i < s3.length(); i++){
            char c = s3.charAt(i);
            if((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')){
                sum += c;
            }
        }
        System.out.println(s3);
        System.out.println(sum);
    }
}
