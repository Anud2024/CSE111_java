import java.util.Scanner;
public class arrTask4 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("N = ");
        int N = input.nextInt();
        int[] arr = new int[N];

        for (int i = 0; i < arr.length; i++) {
            arr[i] = input.nextInt();
        }

        for (int i = 0; i < arr.length; i++) {
            boolean exist = false;
            for (int j = 0; j < i; j++) {
                if (arr[i] == arr[j]) {
                    exist = true;
                    break;
                }
            }
            if (exist) {
                continue;
            }

            int count = 0;
            for (int j = i ; j < arr.length; j++) {
                if (arr[i] == arr[j]) {
                    count++;
                }
            }
            System.out.println(arr[i] + " appears " + count + " times");
        }
    }
}


