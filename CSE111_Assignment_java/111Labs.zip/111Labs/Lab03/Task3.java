import java.util.Scanner;
public class Task3 {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        String s = input.next();//dream
        for(int i = 0; i < s.length(); i++){
            for(int j = 0; j <= i; j++){
                System.out.print(s.charAt(j));
            }
            System.out.println();
        }
    }
}
