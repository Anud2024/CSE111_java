import java.util.Scanner;
public class Task2{
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        String s1 = input.nextLine();
        String s2 = "";
        for(int i = 0; i < s1.length(); i++){
            char c1 =s1.charAt(i);
            char c2 = ' ';
            if(c1 != 'a'){
                c2 =(char) (c1 - 1);
            }
            else{
                c2 = 'z';
            }
            s2 += c2;
        }
        System.out.println(s2);
    }
}