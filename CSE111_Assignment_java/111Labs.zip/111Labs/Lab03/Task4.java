import java.util.Scanner;
public class Task4 {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        while(true){
            String s = input.nextLine(); //Saad
            int count = 0;
            char c = ' ';
            for(int i = 0; i < s.length(); i++){
                c = s.charAt(i);  
                for(int j = 0; j < s.length(); j++){
                    char c2 = s.charAt(j); 
                    if(c == c2){
                        count++;
                        
                    }
                }
                if(count > 1){ 
                    break;
                }
                else{
                    count=0;
                }
            }
            if(count == 0){
                System.out.println("You entered "+s+".");
                break;
            }
            else{
                System.out.println("\""+c + "\" has been counted "+count + " times in the word \""+s+"\"");
                System.out.println("Please enter another word.");
            }
        }
    }
}
