import java.util.Scanner;
public class arrTask3 {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        System.out.print("Enter the length of the array:");
        int N = input.nextInt();
        int[] arr = new int[N];
        for(int i = 0; i < arr.length; i++){
            arr[i] = input.nextInt();
        }
        for(int i = 0, j = arr.length-1; i < arr.length/2; i++, j--){
            int a = arr[i];
            arr[i] = arr[j];
            arr[j] = a;
        }
        for(int i = 0; i< arr.length; i++){
            System.out.print(arr[i]+" ");
        }
    }
}
