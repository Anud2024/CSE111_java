import java.util.Scanner;
public class Task6{
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        String s = input.nextLine(); ///AAAABBBCCADD
        String s2 = "";
        int count = 0;
        for(int i = 0; i < s.length(); i += count){
            count = 0;
            char c1 = s.charAt(i); //b
            for(int j = i; j < s.length(); j++){
                char c2 = s.charAt(j);
                if(c1 == c2){
                    count++;
                }
                else{
                    break;
                }
            }
            s2 += c1;//AB
        }
        System.out.println(s2);
    }
}