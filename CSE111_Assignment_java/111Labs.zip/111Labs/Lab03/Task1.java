import java.util.Scanner;
public class Task1{
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        String s = input.nextLine();
        boolean palindrome = false;
        int i = 0;
        int j = s.length()-1;
        boolean  paliandrome = false; ////////////maddxm
        // while(i < s.length()/2){
        //     char c = s.charAt(i);
        //     char d = s.charAt(j);
        //     if(c == d){
        //         paliandrome = true;
        //     }
        //     else{
        //         paliandrome = false;
        //         break;
        //     }
        //     i++;
        //     j--;

        // }
        for(int i = 0, j = s.length()-1; i<=s.length()/2; i++, j--){
            char c1 = s.charAt(i);
            char c2 = s.charAt(j);
            if(c1 == c2){
                palindrome = true;
            }
            else{
                paliandrome = false;
            }
        }
        if(palindrome){
            System.out.println("Palindrome");
        }
        else{
            System.out.println("Not a paliandrome");
        }
    }
}