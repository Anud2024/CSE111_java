import java.util.Scanner;
public class arrTask6 {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        int N = input.nextInt();
        int[] arr = new int[N];
        for(int i = 0; i < arr.length; i++){
            arr[i] = input.nextInt();
        }
        for(int i = 0; i < arr.length; i++){
            for(int j = i+1; j < arr.length; j++){
              int temp = 0;
              if(arr[i]> arr[j]){
                temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
              }
            }
        }
        int median = 0;
        if(N%2==0){
            int mid1 = arr[(N/2)-1];
            int mid2 = arr[(N/2)];
            median = (mid1 + mid2)/2;
        }
        else{
            median = arr[(N/2)];
        }
        System.out.println("The median is "+ median);
    }
}
