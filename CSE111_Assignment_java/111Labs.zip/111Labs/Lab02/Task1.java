public class Task1{
    public static void main(String[] args){
        //a
        int num = 2;
        while(num<50){
            System.out.print(num+ ", ");
            num+=4;
        }
        System.out.println(num);

        //b
        int n = 1;
        int i = 1;
        while(n<120){
            System.out.print(n+", ");
            i++;
            n+=i;
        }
        System.out.println(n);

    }
}