import java.util.Scanner;
public class Task9 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        //a
        int num1 = input.nextInt();
        int digitCount = 0;
        while(true){
            num1 /= 10;
            digitCount++;
            if(num1==0){
                break;
            }
        }
        System.out.println(digitCount+" digits");

        //b
        int num = input.nextInt();
        int num2 = num;
        int digitCountB = 0;
        while(true){
            num /= 10;
            digitCountB++;
            if(num==0){
                break;
            }
        }
        while(num2>1){
            int div = 1;
            for(int i = 1; i < digitCountB; i++){
                div *= 10;
            }
            int a = num2 / div;
            System.out.print(a*7+ " ");
            num2 %= div;
            digitCountB--;
        }
    }
}
