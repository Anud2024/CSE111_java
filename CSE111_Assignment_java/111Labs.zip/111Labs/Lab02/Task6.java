import java.util.Scanner;
public class Task6 {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        double sumW = 0, sumWN = 0;
        for(int i = 0; i<5; i++){
            double num = input.nextDouble();
            double weight = input.nextDouble();
            sumW += weight;
            sumWN += num * weight;
        }
        double wAvegage = sumWN/sumW;
        System.out.println("Weighted Average = "+wAvegage);
    }
}
