import java.util.Scanner;
public class Task3 {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        int num = input.nextInt();
        int max = num;
        int min = num;
        int sum = num;
        for(int i = 0; i<9; i++){
            num = input.nextInt();
            if(num>max){
                max = num;
            }
            if(num<min){
                min = num;
            }
            sum += num;
        }
        double avg = sum/10.0;
        System.out.println("Sum = "+sum);
        System.out.println("Minimum = "+min);
        System.out.println("Maximum = "+max);
        System.out.println("Average = "+avg);
    }
}
