import java.util.Scanner;
public class Task10{
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        int total = input.nextInt();
        int n500 = 0, n100 = 0, n50 = 0, n10 = 0, n5 = 0, n1 = 0;
        while(total >= 500){
            total-=500;
            n500++;
        }
        while(total>=100){
            total -=100;
            n100++;
        }
        while(total >= 50){
            total -= 50;
            n50++;
        }
        while(total >= 10){
            total -= 10;
            n10++;
        }
        while(total >= 5){
            total -= 5;
            n5++;
        }
        while(total>=1){
            total -=1;
            n1 ++;
        }
        if(n500!=0){
            System.out.println(n500+" 500's note");
        }
        if(n100!=0){
            System.out.println(n100+" 100's note");
        }
        if(n50!=0){
            System.out.println(n50+" 50's note");
        }
        if(n10!=0){
            System.out.println(n10+" 10's note");
        }
        if(n5!=0){
            System.out.println(n5+" 5's note");
        }
        if(n1!=0){
            System.out.println(n1+" 1's note");
        }
    }
}