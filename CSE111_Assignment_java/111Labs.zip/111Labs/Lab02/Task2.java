public class Task2 {
    public static void main(String[] args){
        for(int i = 2; i < 20; i+=2){
            System.out.print(i+", ");
        }
        for(int i = 20; i>2; i-=2){
            System.out.print(i+", ");
        }
        System.out.println(2);
    }
}
