import java.util.Scanner;
public class Task8 {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        int a = input.nextInt();
        int b = input.nextInt();
        int low = a, up = b;
        if(a>b){
            low = b;
            up = a;
        }
        int count = 0;
        for(int i = low; i < up; i++){
            boolean prime = true;
            if(i==1){
                prime = false;
            }
            else if(i == 2){
                prime = true;
            }
            for (int j = 2; j < i; j++){  
                if(i%j==0){
                    prime = false;
                    break;
                }
                else{
                    prime = true;
                }         
            }
            if(prime){
                count++;
            }
        }
        System.out.println("There are "+count+" prime numbers between "+low+" and "+up);
    }
}
