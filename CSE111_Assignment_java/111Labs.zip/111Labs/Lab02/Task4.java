import java.util.Scanner;
public class Task4 {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        int num = input.nextInt();
        int max = 0;
        int min = 0;
        int sum = 0;
        int count = 0;
        if(num > 0 && !(num%2==0)){
            max = num;
            min = num;
            sum = num;
            count++;
        }
        for(int i = 0; i<9; i++){
            num = input.nextInt();
            if(num > 0 && !(num%2==0)){
                count++;
                if(num>max){
                    max = num;
                }
                if(num<min){
                    min = num;
                }
                sum += num;
            }
        }
        if(count!=0){
            double avg = (double) sum/count;
            System.out.println("Sum = "+sum);
            System.out.println("Minimum = "+min);
            System.out.println("Maximum = "+max);
            System.out.println("Average = "+avg);
        }
        else{
            System.out.println("No odd positive number found");
        }
    }
}
