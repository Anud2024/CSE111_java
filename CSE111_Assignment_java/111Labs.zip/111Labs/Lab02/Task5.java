import java.util.Scanner;
public class Task5{
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        int num = input.nextInt();
        int max = 0, min = 0, sum = 0, numCount = 0, zeroCount = 0;
        if(num != 0){
            max = num;
            min = num;
            sum = num;
            numCount++;
        }
        else{
            zeroCount++;
        }
        while(true){
            num = input.nextInt();
            if(num!=0){
                if(num>max){
                    max = num;
                }
                if(num<min){
                    min = num;
                }
                sum+=num;
                numCount++;
                zeroCount = 0;
            }
            else{
                zeroCount++;
            }
            if(zeroCount==3){
                break;
            }
        }
        if(numCount== 0){
            System.out.println("No numbers found");
        }
        else{
            double avg = (double) sum / numCount;
            System.out.println("Sum = "+sum);
            System.out.println("Minimum = "+min);
            System.out.println("Maximum = "+max);
            System.out.println("Average = "+avg);
        }
    }
}
