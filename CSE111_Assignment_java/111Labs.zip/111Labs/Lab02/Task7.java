import java.util.Scanner;
public class Task7 {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        int end = input.nextInt();
        int a = 0, b = 1, n = 0, sum = 0;
        while(n < end){
            n = a + b;
            a = b;
            sum += a;
            System.out.print(a + " ");
            b = n;
        }
        System.out.println();
        System.out.println(sum);
    }
}
