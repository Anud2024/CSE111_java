//Task11
import java.util.Scanner;
public class Task11 {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        int x = input.nextInt();
        int result = 0;
        if(x < 0){
            result = 2 * x;
        }
        else if(x >= 0 && x < 2){
            result = x + 1;
        }
        else if(x >= 2 && x < 5){
            result = (x*x) - 1;
        }
        else{
            result = 3 * (x*x) + 2;
        }
        System.out.println(result);
    }
}