//Task6 
import java.util.Scanner;
public class Task6{
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        int year = input.nextInt();
        boolean leapyear = false;
        if(year%100==0){
            if(year%400==0){
                leapyear = true;
            }
        }
        else{
            if(year%4==0){
                leapyear = true;
            }
        }
        if(leapyear){
            System.out.println(year+" is a leap year");
        }
        else{
            System.out.println(year+" is not a leap year");
        }
    }
}