//Tast1
import java.util.Scanner;
public class Task1{
    public static void main(String[] args){
        //A
        int a = 40;
        System.out.println("The value sorted in variable a is : "+a);

        //B
        int b = 20;
        System.out.println("Addition: " + (a+b));

        //C
        System.out.println("Products: "+(a*b));
        System.out.println("Division: "+(a/b));

        //D
        double x = 30.0;
        System.out.println("x is : "+x);
        double y = 13.5;
        System.out.println("Addition: "+(x+y));
        System.out.println("Product: "+(x*y));
        System.out.println("Division: "+(x/y));

        //E
        int m = 30;
        System.out.println("x is : "+m);
        double n = 13.5;
        System.out.println("Addition: "+(m+n));
        System.out.println("Product: "+(m*n));
        System.out.println("Division: "+(m/n));

        //F
        String s1 = "Hello";
        System.out.println(s1);
        String s2 = "World";
        System.out.println("Strings addition: "+(s1+s2));
        System.out.println("Integer and String addition:" +(a+s2)); //a is a int and s2 is a String
        
        //G
        Scanner input = new Scanner(System.in);
        int a1 = input.nextInt();
        System.out.println("The value sorted in variable a is : "+a1);
        int b1 = input.nextInt();
        System.out.println("Addition: " + (a1+b1));
    }
}