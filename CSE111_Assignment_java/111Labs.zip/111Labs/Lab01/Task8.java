//Task 8 
import java.util.Scanner;
public class Task8 {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        int ID = input.nextInt();
        int first3 = ID/100000;
        int year = first3/10;
        int sem = first3%10;
        String semString = "";
        if(sem==1){
            semString = "Spring";
        }
        else if(sem == 2){
            semString = "Fall";
        }
        else{
            semString = "Summer";
        }
        System.out.println("Student Joined BRAC in "+semString+" "+ year);
    }
}
