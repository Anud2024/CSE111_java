//Task2
public class Task2 {
    public static void main(String[] args){
        int a = 20;
        int b = 30;
        //by creating a third variable
        System.out.println("Before swap: ");
        System.out.println("a is : "+a);
        System.out.println("b is : "+b);

        int c;
        c = a;
        a = b;
        b = c;
        System.out.println("After swap: ");
        System.out.println("a is : "+a);
        System.out.println("b is : "+b);

        //without creating any variable
        System.out.println("Without creating any variable");
        int x = 40;
        int y = 10;
        System.out.println("Before swap: ");
        System.out.println("x is : "+x);
        System.out.println("y is : "+y);
        x = x + y;
        y = x - y;
        x = x - y;
        System.out.println("After swap: ");
        System.out.println("x is : "+x);
        System.out.println("y is : "+y);
        
    }
}