//Task7
import java.util.Scanner;
public class Task7 {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        int num = input.nextInt();
        boolean d5 = (num%5==0);
        boolean d7 = (num%7==0);
        if(d5 && d7){
            System.out.println("Divisible by Both");
        }
        else if(d5){
            System.out.println("Invalid: Divisible by 5 only");
        }
        else if(d7){
            System.out.println("Invalid: Divisible by 7 only");
        }
        else{
            System.out.println("No");
        }
    }
}