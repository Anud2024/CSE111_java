//Task9
import java.util.Scanner;
public class Task9 {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        double cg = input.nextDouble();
        int credit = input.nextInt();
        if(credit>=30 && cg >= 3.8){
            int schoolarship = 0;
            if(cg>=3.8 && cg <= 3.89){
                schoolarship = 25;
            }
            else if(cg >= 3.90 && cg <= 3.94){
                schoolarship = 50;
            }
            else if(cg >= 3.95 && cg <= 3.99){
                schoolarship = 75;
            }
            else if(cg==4.00){
                schoolarship = 100;
            }
            System.out.println("The student is eligible for a waiver of "+schoolarship + " percent");
        }
        else{
            System.out.println("The student is not eligible for a waiver");
        }
    }
}