//Task3 
public class Task3 {
    public static void main(String[] args){
        int ID = 24101168;
        int last2 = ID % 100;
        System.out.println(last2%10);
        System.out.println(last2/10);
    }
}