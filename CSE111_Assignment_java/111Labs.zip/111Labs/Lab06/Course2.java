public class Course2 {
    public String name;
    public String code;
    public String[] syllabus;
    public int count;

    public void createCourse(String name, String code){
        this.name = name;
        this.code = code;
        syllabus = new String[4];
    }

    public void addContent(String topic){
        if(count<4){
            syllabus[count] = topic;
            System.out.println(topic+ " was added.");
            count++;
        }
        else{
            System.out.println("Cannot add more content");
        }
    }
    public void addContent(String topic1, String topic2){
        addContent(topic1);
        addContent(topic2);
    }

    public void printDetails(){
        System.out.println("Course Name: "+name);
        System.out.println("Course Code: "+code);
        System.out.println("Course Syllabus:");
        if(count == 0){
            System.out.println("No content yet.");
        }
        else{
            if(count>1){
                for(int i = 0; i < count-1; i++){
                    System.out.print(syllabus[i]+", ");
                }
                System.out.println(syllabus[count-1]);
            }
            else{
                System.out.println(syllabus[0]);
            }
        }
    }
}
