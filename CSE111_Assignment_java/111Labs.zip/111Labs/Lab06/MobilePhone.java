public class MobilePhone {
    public int capacity;
    public String[] contactList;
    public int[] contactListN;
    public int count;

    public void setContactCapacity(int capacity){
        this.capacity = capacity;
        this.contactList = new String[capacity];
        this.contactListN = new int[capacity];
    }

    public void addContact(String name, int num){
        if(count<capacity) {
            contactList[count] = name;
            contactListN[count] = num;
            System.out.println("The contact of "+name+" is added");
            count++;
        }
        else{
            System.out.println("Storage full!!");
        }
    }

    public void makeCall(int num){
        boolean found = false;
        for(int i = 0; i < contactListN.length; i++){
            if(num == contactListN[i]){
                System.out.println("Calling "+contactList[i]+" . . .");
                found = true;
                break;
            }
        }
        if(!found){
            System.out.println("Calling "+num+ " . . .");
        }
    }
    public void details(){
        System.out.println("Total Contacts: "+count);
        System.out.println("Contact List:");
        if(count!=0) {
            for (int i = 0; i < contactList.length; i++) {
                System.out.println(contactList[i] + ":" + contactListN[i]);
            }
        }
    }
}
