public class Shape {
    public String name;
    public double area;

    public void setParameters(String name, double radius){
        this.name = name;
        area = 3.1416 * radius * radius;
    }
    public void setParameters(String name, double a, double b){
        this.name = name;
        area = .5 * a * b;
    }
    public void setParameters(String name, double a, double b , double h){
        this.name = name;
        area = .50 * (a+b) * h;
    }
    public String details(){
        return "Shape Name: "+name+"\nArea: "+area;
    }
}
