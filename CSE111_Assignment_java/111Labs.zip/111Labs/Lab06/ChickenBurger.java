public class ChickenBurger {
    public String bun = "Sesame";
    public int price = 200;
    public String sauceOption = "Less";
    public String spiceLevel = "Not Set";

    public void customizeSpiceLevel(String level){
        if(level.equals("Mild")||level.equals("Spicy")||level.equals("Naga")||level.equals("Extreme")){
            if(level.equals("Mild")){
                spiceLevel = "Mild";
            }
            else if(level.equals("Spicy")){
                spiceLevel = "Spicy";
            }
            else if(level.equals("Naga")){
                spiceLevel = "Naga";
            }
            else if(level.equals("Extreme")){
                spiceLevel = "Extreme";
            }
            System.out.println("Spice level set to "+level+".");
        }
        else{
            System.out.println("This spice level is unavailable.");
        }
    }

    public String serveBurger(){
        if(spiceLevel.equals("Not Set")){
            return "Cannot serve now. Customize Spice Level first.";
        }
        else{
            return "The burger is being served:-\nBun Type: "+bun+"\nPrice: "+price+"\nSauce Option: "+sauceOption+"\nSpice Level: "+spiceLevel;
        }
    }
}

