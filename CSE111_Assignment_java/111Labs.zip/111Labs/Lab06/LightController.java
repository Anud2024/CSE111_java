public class LightController {
    public boolean status;
    public int level;

    public void adjustBrightness(int level){
        if(status){
            if(this.level + level <= 10){
                this.level += level;
                System.out.println("Brightness adjusted.");
            }
            else{
                System.out.println("Brightness out of range. Set between 0 to 10.");
            }
        }
        else{
            System.out.println("Please turn on the light first!");
        }
    }

    public void switchLight(){
        status = !status;
        if(status){
            System.out.println("Lights are now ON");
            level = 1;
        }
        else{
            System.out.println("Lights are now OFF");
            level = 0;
        }
    }

    public String resetSettings(){
        status = true;
        level = 1;
        return "Light settings have been reset.";
    }


    public void showLightStatus(){
        if(status){
            System.out.println("Light status: ON");
        }
        else{
            System.out.println("Light status: OFF");
        }
        System.out.println("Brightness Level: "+level);
    }

}
